//
//  ThreeViewController.h
//  SkinDemo
//
//  Created by 1 on 15/8/13.
//  Copyright (c) 2015年 Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThreeViewController : UIViewController
{
    NSArray *arr;
}
@end
