//
//  ViewController.m
//  SkinDemo
//
//  Created by 1 on 15/8/13.
//  Copyright (c) 2015年 Lee. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController

- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
        self.title = @"1";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    SkinManager *manager = [SkinManager manager];
    [manager addObserver:self forKeyPath:@"bgColor" options:NSKeyValueObservingOptionNew context:nil];
    self.view.backgroundColor = manager.bgColor;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    self.view.backgroundColor = [SkinManager manager].bgColor;

    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    UITabBarController *tabBarController = (UITabBarController *)appDelegate.window.rootViewController;
    tabBarController.tabBar.tintColor =[SkinManager manager].bgColor;
    
    

}

- (void)dealloc{
    [[SkinManager manager] removeObserver:self forKeyPath:@"bgColor"];
    
}
@end
