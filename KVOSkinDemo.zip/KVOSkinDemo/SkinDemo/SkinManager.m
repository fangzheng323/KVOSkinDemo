//
//  SkinManager.m
//  SkinDemo
//
//  Created by 1 on 15/8/13.
//  Copyright (c) 2015年 Lee. All rights reserved.
//

#import "SkinManager.h"

@implementation SkinManager
static SkinManager *manager = nil;
+ (SkinManager *)manager
{
    if (manager) {
        return manager;
    }

    manager = [SkinManager new];
    return manager;

}
- (id)init{
    self = [super init];
    if (self) {
        self.bgColor = [UIColor yellowColor];
        

    }
    return self;
}


@end
