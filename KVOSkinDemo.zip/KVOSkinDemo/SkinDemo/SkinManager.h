//
//  SkinManager.h
//  SkinDemo
//
//  Created by 1 on 15/8/13.
//  Copyright (c) 2015年 Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SkinManager : NSObject
@property (nonatomic,strong) UIColor *bgColor;
+ (SkinManager *)manager;
@end
