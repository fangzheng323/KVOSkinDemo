//
//  ThreeViewController.m
//  SkinDemo
//
//  Created by 1 on 15/8/13.
//  Copyright (c) 2015年 Lee. All rights reserved.
//

#import "ThreeViewController.h"

@interface ThreeViewController ()

@end

@implementation ThreeViewController
- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
        self.title = @"3";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [SkinManager manager].bgColor;
    [[SkinManager manager] addObserver:self forKeyPath:@"bgColor" options:NSKeyValueObservingOptionNew context:nil];
    
    arr = @[[UIColor redColor],[UIColor blueColor],[UIColor greenColor],[UIColor yellowColor]];
    
    for (int i = 0 ; i < arr.count; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0.0f, i*60.0f+20.0f, 80.0f, 40.0f);
        button.tag = i +1;
        button.backgroundColor = arr[i];
        [button addTarget:self action:@selector(buttonTouch:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
        
        
    }
    
    
}
- (void)buttonTouch:(UIButton *)sender{
    SkinManager *manager = [SkinManager manager];
    manager.bgColor = arr[sender.tag-1];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    
    self.view.backgroundColor = [SkinManager manager].bgColor;
    
    
}
- (void)dealloc{
    [[SkinManager manager] removeObserver:self forKeyPath:@"bgColor"];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
